/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matheussamuel;

/**
 *
 * @author 00356182
 */
public class MatheusSamuel {

    public static void main(String[] args) {
        NotaFam obj = new NotaFam();

        obj.EntrarNomeAluno();
        obj.EntrarDisciplina();
        obj.EntrarNotaA1();
        obj.EntrarNotaA2();

        obj.CalMedia();

        if (obj.media < 6) {
            obj.ValidarNota();
            obj.EntrarNotaA3();
            obj.SubstituirNota();
            obj.CalMedia();
        }

        obj.CalcStatus1();
        obj.CalcStatus2();
        obj.ExibeBoletim();
        obj.Sair();
    }
}
