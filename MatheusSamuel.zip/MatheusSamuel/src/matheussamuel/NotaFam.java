/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matheussamuel;

import java.util.Scanner;

/**
 *
 * @author 00356182
 */
public class NotaFam {

    Scanner entrada = new Scanner(System.in);
    String nome, disciplina, status;
    double a1, a2, a3;
    double media;

    public void EntrarNomeAluno() {
        System.out.println("Informe o nome do aluno: ");
        nome = entrada.nextLine();
    }

    public void EntrarDisciplina() {
        System.out.println("Digite o nome da disciplina: ");
        disciplina = entrada.nextLine();
    }

    public void EntrarNotaA1() {
        System.out.println("Digite a nota A1: ");
        a1 = entrada.nextDouble();
        if (a1 < 0 || a1 > 5) {
            System.out.println("Nota Inválida!");
            EntrarNotaA1();
        }
    }

    public void EntrarNotaA2() {
        System.out.println("Digite a nota A2: ");
        a2 = entrada.nextDouble();
        if (a2 < 0 || a2 > 5) {
            System.out.println("Nota Inválida!");
            EntrarNotaA2();
        }
    }

    public void EntrarNotaA3() {
        System.out.println("Digite a nota A3: ");
        a3 = entrada.nextDouble();
        if (a3 < 0 || a3 > 5) {
            System.out.println("Nota Inválida!");
            EntrarNotaA3();
        }
    }

    public void CalMedia() {
        media = (a1 + a2);
    }

    public void SubstituirNota() {
        if (a1 < a2 && a3 > a1) {
            a1 = a3;
        } else if (a2 < a1 && a3 > a2) {
            a2 = a3;
        }
    }

    public void CalcStatus1() {
        if (media >= 6) {
            status = "APROVADO";
        }
    }

    public void CalcStatus2() {
        if (media < 6) {
            status = "REPROVADO";
        }
    }

    public void ValidarNota() {
        System.out.println("O aluno não alcançou a média e precisa fazer a A3");
    }

    public void ExibeBoletim() {
        System.out.println("******* BOLETIM DO ALUNO *******");
        System.out.println("Aluno: " + nome);
        System.out.println("Disciplina: " + disciplina);
        System.out.println("Nota A1: " + a1);
        System.out.println("Nota A2: " + a2);
        System.out.println("Nota A3: " + a3);
        System.out.println("Média final: " + media);
        System.out.println("Situação do aluno: " + status);
    }

    public void Sair() {
        System.out.println("******* SISTEMA ENCERRADO *******");
    }
}
